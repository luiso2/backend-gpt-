'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';

interface AIPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const AIPanel: React.FC<AIPanelProps> = ({ isOpen, onClose }) => {
  const { t } = useLanguage();
  const [selectedMode, setSelectedMode] = useState<'build' | 'automate' | 'analyze'>('build');
  const [prompt, setPrompt] = useState('');

  // CSS-in-JS Styles
  const styles = {
    overlay: {
      position: 'fixed' as const,
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.8)',
      backdropFilter: 'blur(10px)',
      zIndex: 9999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px',
    },
    panel: {
      position: 'relative' as const,
      width: '95vw',
      maxWidth: '1200px',
      height: '95vh',
      maxHeight: '900px',
      backgroundColor: '#0A2E1F',
      borderRadius: '20px',
      border: '1px solid rgba(184, 233, 45, 0.2)',
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column' as const,
      boxShadow: '0 20px 60px rgba(0, 0, 0, 0.5)',
    },
    header: {
      padding: '30px',
      borderBottom: '1px solid rgba(184, 233, 45, 0.1)',
      background: 'linear-gradient(180deg, rgba(184, 233, 45, 0.1) 0%, rgba(10, 46, 31, 0) 100%)',
    },
    headerTop: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '20px',
    },
    title: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: '#B8E92D',
      margin: 0,
    },
    closeButton: {
      width: '40px',
      height: '40px',
      borderRadius: '50%',
      backgroundColor: 'rgba(255, 255, 255, 0.1)',
      border: 'none',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'all 0.3s ease',
      color: '#fff',
    },
    modes: {
      display: 'flex',
      gap: '10px',
      flexWrap: 'wrap' as const,
    },
    modeButton: {
      padding: '10px 20px',
      borderRadius: '10px',
      border: '1px solid rgba(184, 233, 45, 0.3)',
      backgroundColor: 'transparent',
      color: '#fff',
      fontSize: '16px',
      fontWeight: '500',
      cursor: 'pointer',
      transition: 'all 0.3s ease',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
    },
    modeButtonActive: {
      backgroundColor: 'rgba(184, 233, 45, 0.2)',
      borderColor: '#B8E92D',
      color: '#B8E92D',
    },
    content: {
      flex: 1,
      padding: '30px',
      overflowY: 'auto' as const,
      display: 'flex',
      flexDirection: 'column' as const,
      gap: '30px',
    },
    promptSection: {
      display: 'flex',
      flexDirection: 'column' as const,
      gap: '15px',
    },
    promptLabel: {
      fontSize: '18px',
      fontWeight: '500',
      color: '#fff',
    },
    promptTextarea: {
      width: '100%',
      minHeight: '150px',
      padding: '15px',
      backgroundColor: 'rgba(255, 255, 255, 0.05)',
      border: '1px solid rgba(184, 233, 45, 0.3)',
      borderRadius: '10px',
      color: '#fff',
      fontSize: '16px',
      resize: 'vertical' as const,
      outline: 'none',
      transition: 'all 0.3s ease',
      fontFamily: 'inherit',
    },
    suggestionsSection: {
      display: 'flex',
      flexDirection: 'column' as const,
      gap: '15px',
    },
    suggestionsTitle: {
      fontSize: '16px',
      fontWeight: '500',
      color: 'rgba(255, 255, 255, 0.7)',
    },
    suggestionsGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
      gap: '10px',
    },
    suggestionCard: {
      padding: '15px',
      backgroundColor: 'rgba(255, 255, 255, 0.05)',
      border: '1px solid rgba(184, 233, 45, 0.2)',
      borderRadius: '10px',
      cursor: 'pointer',
      transition: 'all 0.3s ease',
    },
    suggestionText: {
      fontSize: '14px',
      color: 'rgba(255, 255, 255, 0.8)',
      margin: 0,
    },
    footer: {
      padding: '20px 30px',
      borderTop: '1px solid rgba(184, 233, 45, 0.1)',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: '20px',
      flexWrap: 'wrap' as const,
    },
    submitButton: {
      padding: '12px 30px',
      backgroundColor: '#B8E92D',
      color: '#0A2E1F',
      border: 'none',
      borderRadius: '10px',
      fontSize: '16px',
      fontWeight: '600',
      cursor: 'pointer',
      transition: 'all 0.3s ease',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
    },
    footerInfo: {
      fontSize: '14px',
      color: 'rgba(255, 255, 255, 0.6)',
    },
  };

  const modes = [
    {
      id: 'build' as const,
      name: t.ai.modes.build,
      icon: '🛠️',
      description: t.ai.descriptions.build,
    },
    {
      id: 'automate' as const,
      name: t.ai.modes.automate,
      icon: '⚡',
      description: t.ai.descriptions.automate,
    },
    {
      id: 'analyze' as const,
      name: t.ai.modes.analyze,
      icon: '📊',
      description: t.ai.descriptions.analyze,
    },
  ];

  const suggestions = {
    build: [
      'Create a modern e-commerce website with payment integration',
      'Build a real-time dashboard for business analytics',
      'Develop a mobile-responsive portfolio site',
      'Design a customer management system',
    ],
    automate: [
      'Automate invoice generation and email delivery',
      'Set up automatic social media posting',
      'Create workflow for lead management',
      'Build automated report generation system',
    ],
    analyze: [
      'Analyze website performance and SEO metrics',
      'Review business processes for automation opportunities',
      'Evaluate current tech stack efficiency',
      'Assess digital transformation readiness',
    ],
  };

  const handleSubmit = () => {
    console.log('Submitted:', { mode: selectedMode, prompt });
    // Add your submission logic here
  };

  const handleSuggestionClick = (suggestion: string) => {
    setPrompt(suggestion);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          style={styles.overlay}
          onClick={(e) => {
            if (e.target === e.currentTarget) onClose();
          }}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ duration: 0.3 }}
            style={styles.panel}
          >
            {/* Header */}
            <div style={styles.header}>
              <div style={styles.headerTop}>
                <h2 style={styles.title}>{t.ai.title}</h2>
                <button
                  style={styles.closeButton}
                  onClick={onClose}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = 'rgba(184, 233, 45, 0.2)';
                    e.currentTarget.style.color = '#B8E92D';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
                    e.currentTarget.style.color = '#fff';
                  }}
                >
                  ✕
                </button>
              </div>
              
              <div style={styles.modes}>
                {modes.map((mode) => (
                  <button
                    key={mode.id}
                    style={{
                      ...styles.modeButton,
                      ...(selectedMode === mode.id ? styles.modeButtonActive : {}),
                    }}
                    onClick={() => setSelectedMode(mode.id)}
                    onMouseEnter={(e) => {
                      if (selectedMode !== mode.id) {
                        e.currentTarget.style.backgroundColor = 'rgba(184, 233, 45, 0.1)';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (selectedMode !== mode.id) {
                        e.currentTarget.style.backgroundColor = 'transparent';
                      }
                    }}
                  >
                    <span>{mode.icon}</span>
                    <span>{mode.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Content */}
            <div style={styles.content}>
              <div style={styles.promptSection}>
                <label style={styles.promptLabel}>
                  {modes.find(m => m.id === selectedMode)?.description}
                </label>
                <textarea
                  style={styles.promptTextarea}
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder={t.ai.placeholder}
                  onFocus={(e) => {
                    e.currentTarget.style.borderColor = '#B8E92D';
                    e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.08)';
                  }}
                  onBlur={(e) => {
                    e.currentTarget.style.borderColor = 'rgba(184, 233, 45, 0.3)';
                    e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
                  }}
                />
              </div>

              <div style={styles.suggestionsSection}>
                <h3 style={styles.suggestionsTitle}>{t.ai.suggestions}</h3>
                <div style={styles.suggestionsGrid}>
                  {suggestions[selectedMode].map((suggestion, index) => (
                    <div
                      key={index}
                      style={styles.suggestionCard}
                      onClick={() => handleSuggestionClick(suggestion)}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = 'rgba(184, 233, 45, 0.1)';
                        e.currentTarget.style.borderColor = '#B8E92D';
                        e.currentTarget.style.transform = 'translateY(-2px)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
                        e.currentTarget.style.borderColor = 'rgba(184, 233, 45, 0.2)';
                        e.currentTarget.style.transform = 'translateY(0)';
                      }}
                    >
                      <p style={styles.suggestionText}>{suggestion}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div style={styles.footer}>
              <span style={styles.footerInfo}>
                {t.ai.powered}
              </span>
              <button
                style={styles.submitButton}
                onClick={handleSubmit}
                disabled={!prompt.trim()}
                onMouseEnter={(e) => {
                  if (prompt.trim()) {
                    e.currentTarget.style.transform = 'translateY(-2px)';
                    e.currentTarget.style.boxShadow = '0 6px 20px rgba(184, 233, 45, 0.4)';
                  }
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }}
              >
                <span>{t.ai.submit}</span>
                <span>→</span>
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AIPanel;