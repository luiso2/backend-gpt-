import { NextRequest, NextResponse } from 'next/server'
import nodemailer from 'nodemailer'

interface LeadData {
  name: string
  email: string
  phone: string
  company: string
  requirements: string
  serviceInterest: string
}

export async function POST(request: NextRequest) {
  try {
    const leadData: LeadData = await request.json()

    // Validate required fields
    if (!leadData.name || !leadData.email || !leadData.serviceInterest) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Create transporter for sending emails
    const transporter = nodemailer.createTransporter({
      host: process.env.SMTP_HOST || 'smtp.gmail.com',
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: false,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    })

    // Email content
    const emailContent = `
      <h2>Nuevo Lead de Servicio - MERCATOP</h2>
      <h3>Información del Cliente:</h3>
      <ul>
        <li><strong>Nombre:</strong> ${leadData.name}</li>
        <li><strong>Email:</strong> ${leadData.email}</li>
        <li><strong>Teléfono:</strong> ${leadData.phone}</li>
        <li><strong>Empresa:</strong> ${leadData.company}</li>
        <li><strong>Servicio de Interés:</strong> ${leadData.serviceInterest}</li>
      </ul>
      <h3>Requerimientos:</h3>
      <p>${leadData.requirements}</p>
      <hr>
      <p><em>Este lead fue generado automáticamente desde el chat de IA en la página de servicios.</em></p>
    `

    // Send email
    await transporter.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to: process.env.LEADS_EMAIL || 'leads@mercatop.com',
      subject: `Nuevo Lead: ${leadData.serviceInterest} - ${leadData.name}`,
      html: emailContent,
    })

    // Here you could also save to database if needed
    // await saveLeadToDatabase(leadData)

    return NextResponse.json(
      { message: 'Lead sent successfully' },
      { status: 200 }
    )
  } catch (error) {
    console.error('Error processing lead:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}